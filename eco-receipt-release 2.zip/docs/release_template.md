# Release v0.1.0 — Hackathon MVP

## Summary
This release contains the EcoReceipt starter MVP optimized for Build-a-thon 2025 demo submission.

## Quickstart
- Backend: see backend/README instructions
- Frontend: see frontend/README instructions
- Docker: `docker-compose up --build`

## Notable files
- infra/supabase_schema.sql
- demo-assets/animated-demo.gif
- demo-assets/narration_storyboard.md
- RELEASE_NOTES.md

## Changelog
See RELEASE_NOTES.md
