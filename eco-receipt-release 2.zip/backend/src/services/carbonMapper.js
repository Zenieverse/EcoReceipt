// carbonMapper.js
// Tries to resolve a product/item name to an emission factor using Climatiq (if available),
// otherwise falls back to local lookup in infra/carbon_lookup.json.
import fs from 'fs';
import { lookupEmissionFactor } from './climatiqService.js';

const DATA_PATH = new URL('../../infra/carbon_lookup.json', import.meta.url).pathname;
const raw = fs.readFileSync(DATA_PATH, 'utf8');
const localLookup = JSON.parse(raw);

function localFind(name) {
  const n = (name || '').toLowerCase();
  if (n.includes('latte') || n.includes('coffee')) return localLookup.find(e=>e.category==='coffee');
  if (n.includes('beef') || n.includes('steak')) return localLookup.find(e=>e.category==='beef');
  if (n.includes('muffin') || n.includes('bread')) return localLookup.find(e=>e.category==='bread');
  if (n.includes('water')) return localLookup.find(e=>e.category==='default');
  return localLookup.find(e=>e.category==='default');
}

export async function resolveEmissionFactorForItem(name) {
  // 1) Try Climatiq if API key present
  try {
    const res = await lookupEmissionFactor(name);
    if (res && res.co2e_g_per_unit) {
      return { source: 'climatiq', gco2_per_unit: res.co2e_g_per_unit, note: res.name || '' };
    }
  } catch (e) {
    console.warn('Climatiq lookup error', e?.message || e);
  }
  // 2) fallback to local JSON mapping
  const local = localFind(name);
  return { source: 'local', gco2_per_unit: local?.gco2_per_unit || 500, note: local?.category || 'default' };
}
