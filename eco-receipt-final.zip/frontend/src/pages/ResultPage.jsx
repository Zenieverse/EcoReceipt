import React from 'react';

export default function ResultPage({ data, onBack, onDashboard }){
  if (!data) return <div><p>No result</p><button onClick={onBack}>Back</button></div>;
  return (
    <div>
      <h2>Result</h2>
      <p><strong>Estimated CO₂:</strong> {data.estimated_co2_kg} kg</p>
      <h3>Items</h3>
      <ul>
        {data.items.map((it, idx)=>(<li key={idx}>
          <strong>{it.name}</strong> — {it.category} — {it.est_co2_kg} kg
        </li>))}
      </ul>
      <div style={{marginTop:12}}>
        <button onClick={onBack}>Scan another</button>
        <button style={{marginLeft:8}} onClick={onDashboard}>Go to dashboard</button>
      </div>
    </div>
  )
}
