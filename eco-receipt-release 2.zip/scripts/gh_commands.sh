#!/usr/bin/env bash
# Usage: edit GH_USER and REPO before running, or pass them as args
GH_USER="${1:-<GITHUB_USERNAME>}"
REPO="${2:-eco-receipt}"
echo "Creating repo ${GH_USER}/${REPO}..."
git init
git add .
git commit -m "chore: initial EcoReceipt release v0.1.0"
gh repo create "${GH_USER}/${REPO}" --public --source=. --remote=origin --push
# Create release draft
gh release create v0.1.0 --title "v0.1.0 — Hackathon MVP" --notes-file RELEASE_NOTES.md
echo "Repository created and release draft created. Add secrets in repo settings."
