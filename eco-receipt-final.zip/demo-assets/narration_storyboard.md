EcoReceipt — Demo Narration & Storyboard (Professional Pitch, ~2:20)

Total time: 2 minutes 20 seconds

Scene 1 (0:00 - 0:12) — Opening / Problem (12s)
Visual: Title card + logo (animated-demo.gif first frame)
Narration: "Hi, I’m [Name]. Today I’m excited to introduce EcoReceipt — a simple way to see the carbon footprint behind everyday purchases."
Key point: State the problem — purchases have hidden carbon costs; people lack visibility.

Scene 2 (0:12 - 0:32) — Solution overview (20s)
Visual: Quick transition to Scan screen.
Narration: "EcoReceipt turns a receipt into actionable carbon data. Snap a photo or upload your invoice; our system extracts line items, classifies them, and estimates CO₂ — all in seconds."
Key point: Emphasize speed, clarity, and behavior change.

Scene 3 (0:32 - 1:05) — Live demo: Scan → Processing → Result (33s)
Visual: Use GIF frames: capture → processing (animated dots) → show Result with big CO₂ number and items.
Narration: "Here’s a live demo. I capture a receipt, OCR extracts the text, then our classifier maps items to categories and a carbon lookup estimates emissions. The result shows total CO₂ and per-item breakdown, with suggested greener swaps."
Action: Pause briefly on the Result screen to show numbers and one swap suggestion.

Scene 4 (1:05 - 1:30) — Dashboard & Impact (25s)
Visual: Dashboard frame showing monthly total, EcoCredits, category breakdown.
Narration: "Saved receipts feed a dashboard so users can track monthly impact, see category hotspots, and earn EcoCredits for low-carbon choices. This makes carbon visible and actionable."

Scene 5 (1:30 - 1:55) — Tech & Feasibility (25s)
Visual: Quick cut to architecture mermaid diagram (screenshot) or code highlights.
Narration: "Under the hood: React PWA frontend, Node/Express backend, OCR via Google Vision or Tesseract fallback, classification via OpenAI or rule-based mapping, and Supabase for storage. We designed the MVP to be buildable within the hackathon timeline and scalable afterwards."

Scene 6 (1:55 - 2:10) — Roadmap (15s)
Visual: Bullet list slide (Climatiq integration, bank sync, EcoCredits marketplace).
Narration: "Next: integrate Climatiq for authoritative emission factors, add automatic bank-transaction sync, and launch a marketplace for EcoCredits with real sustainability partners."

Scene 7 (2:10 - 2:20) — Ask & Close (10s)
Visual: Logo + call to action (GitHub repo link / contact)
Narration: "We’re submitting a working MVP, code, and demo. Thank you — EcoReceipt: see the CO₂ behind every purchase and make greener choices."

Recording tips:
- Record 1–2 takes per scene; keep each clip concise.
- Use captions for key numbers (CO₂ kg, EcoCredits).
- Keep the demo flow visible; avoid long pauses.
- Total video should be 2–3 minutes to meet hackathon requirements.
