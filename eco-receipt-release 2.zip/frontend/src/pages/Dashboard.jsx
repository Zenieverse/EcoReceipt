import React from 'react';

export default function Dashboard({ data, onBack }){
  return (
    <div>
      <h2>Dashboard</h2>
      <p><strong>Last scan CO₂:</strong> {data?.estimated_co2_kg ?? '—'} kg</p>
      <p>Monthly total (demo): {data?.estimated_co2_kg ?? 0} kg</p>
      <button onClick={onBack}>Back</button>
    </div>
  )
}
