# EcoReceipt — Release Notes (Draft)

## v0.1.0 — Hackathon MVP (Draft)
Date: [RELEASE_DATE]

Highlights
- Starter MVP: React PWA frontend + Node/Express backend
- OCR support: Google Vision (optional), Tesseract fallback for offline/local
- Carbon estimation: local lookup + Climatiq lookup stub
- Persistence: Supabase integration skeleton + SQL schema
- CI: GitHub Actions workflow to run backend tests and build frontend
- Docker support: Dockerfiles and docker-compose for local full-stack deployment
- Demo assets: animated GIF, narration & storyboard for a 2–3 minute demo

Known limitations
- Mock OCR and mock carbon lookup used for demo; enable Climatiq and Google Vision for production accuracy.
- Tesseract.js may require additional system dependencies and is heavier for CI runners.
- Classification accuracy depends on mapping rules / OpenAI integration (not included by default).

How to deploy
- Use the `scripts/create_and_push_repo.sh` to create a GitHub repo (requires gh CLI)
- Use Docker + docker-compose for local testing: `docker-compose up --build`
- For production, deploy frontend to Vercel and backend to Render or Railway; set secrets in provider env vars.

## Changelog
- v0.1.0 — initial full feature MVP (see infra, backend, frontend, demo-assets)
