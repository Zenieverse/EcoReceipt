// Server-side Tesseract OCR integration (Node)
// Uses `tesseract.js` which spawns workers and can process base64 images.
// Install: npm install tesseract.js @ffmpeg-installer/ffmpeg canvas
import { createWorker } from 'tesseract.js';

const worker = createWorker({
  logger: m => {
    // console.log('Tesseract', m);
  }
});

export async function tesseractOCR(base64Image) {
  // base64Image: data URL like "data:image/png;base64,...."
  try {
    await worker.load();
    await worker.loadLanguage('eng');
    await worker.initialize('eng');
    const res = await worker.recognize(base64Image);
    await worker.terminate();
    return res?.data?.text || '';
  } catch (e) {
    console.warn('Tesseract OCR failed', e?.message || e);
    try {
      await worker.terminate();
    } catch {}
    return '';
  }
}
