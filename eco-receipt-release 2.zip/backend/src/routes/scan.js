import express from 'express';
import { processImageOCR } from '../services/ocrService.js';
import { estimateCarbonForItems } from '../services/carbonEstimator.js';
import { saveReceiptToSupabase } from '../services/supabaseService.js';

const router = express.Router();

router.post('/scan', async (req, res) => {
  try {
    const { imageBase64, raw_text, userId } = req.body;
    let ocrText = raw_text;
    if (imageBase64) {
      ocrText = await processImageOCR(imageBase64);
    }
    // Very simple parser: lines with "Name - price"
    const lines = (ocrText || '').split('\n').map(l=>l.trim()).filter(Boolean);
    const items = [];
    for (const line of lines) {
      const m = line.match(/(.+?)\s[-–]\s?(\d+[.,]?\d*)$/);
      if (m) {
        items.push({ name: m[1].trim(), price: parseFloat(m[2].replace(',','.')), quantity:1 });
      } else {
        items.push({ name: line, price: null, quantity:1 });
      }
    }
    const itemsWithCO2 = await estimateCarbonForItems(items);
    const estimatedCo2 = itemsWithCO2.reduce((s,i)=>s+(i.est_co2_kg||0),0);
    const receipt = { receipt_id: 'mock-' + Date.now(), items: itemsWithCO2, estimated_co2_kg: Number(estimatedCo2.toFixed(3)), raw_text: ocrText }
    // Optionally save to Supabase if configured and userId provided
    try {
      if (userId) {
        await saveReceiptToSupabase(userId, receipt);
      }
    } catch(e){
      console.warn('Supabase save failed', e?.message || e);
    }
    res.json(receipt);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'scan failed', detail: String(err) });
  }
});

export default router;
