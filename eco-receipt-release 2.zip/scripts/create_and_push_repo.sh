#!/usr/bin/env bash
# Usage: ./scripts/create_and_push_repo.sh your-github-username eco-receipt
set -e
GH_USER="$1"
REPO_NAME="$2"
if [ -z "$GH_USER" ] || [ -z "$REPO_NAME" ]; then
  echo "Usage: $0 <github-username-or-org> <repo-name>"
  exit 1
fi
git init
git add .
git commit -m "chore: initial EcoReceipt starter MVP (complete)"
gh repo create "${GH_USER}/${REPO_NAME}" --public --source=. --remote=origin --push
echo "Repo created and pushed to https://github.com/${GH_USER}/${REPO_NAME}"
echo "Remember to add secrets: GOOGLE_VISION_API_KEY, CLIMATIQ_API_KEY, SUPABASE_URL, SUPABASE_KEY"
