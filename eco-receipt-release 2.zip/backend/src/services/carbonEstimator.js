import fs from 'fs';
const DATA_PATH = new URL('../../infra/carbon_lookup.json', import.meta.url).pathname;
const raw = fs.readFileSync(DATA_PATH, 'utf8');
const lookup = JSON.parse(raw);

function findCategoryByName(name) {
  const n = name.toLowerCase();
  if (n.includes('latte') || n.includes('coffee')) return 'coffee';
  if (n.includes('muffin') || n.includes('bread')) return 'bread';
  if (n.includes('beef') || n.includes('steak')) return 'beef';
  if (n.includes('water')) return 'default';
  return 'default';
}

export async function estimateCarbonForItems(items) {
  return items.map(item => {
    const category = findCategoryByName(item.name || '');
    const entry = lookup.find(e=>e.category===category) || lookup.find(e=>e.category==='default');
    const gco2 = (entry.gco2_per_unit || 500) * (item.quantity || 1);
    const kg = gco2 / 1000;
    return { ...item, category, est_co2_kg: Number(kg.toFixed(3)) };
  });
}
