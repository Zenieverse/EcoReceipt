-- Supabase / Postgres schema for EcoReceipt MVP
-- Run via psql or supabase CLI

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text,
  full_name text,
  created_at timestamptz default now()
);

create table if not exists receipts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id),
  raw_text text,
  total_amount numeric,
  currency text,
  estimated_co2_kg numeric,
  metadata jsonb,
  uploaded_at timestamptz default now()
);

create table if not exists receipt_items (
  id uuid primary key default gen_random_uuid(),
  receipt_id uuid references receipts(id) on delete cascade,
  name text,
  quantity numeric,
  price numeric,
  category text,
  est_co2_kg numeric
);

create table if not exists eco_credits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id),
  receipt_id uuid references receipts(id),
  credits numeric,
  reason text,
  created_at timestamptz default now()
);
