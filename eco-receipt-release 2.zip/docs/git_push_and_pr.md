# GitHub repo setup & PR template (ready-to-run)

## Create repository and push local files
```bash
# from project root
git init
git add .
git commit -m "chore: initial EcoReceipt starter MVP"
# create repo on GitHub web or use gh CLI:
gh repo create your-username/eco-receipt --public --source=. --remote=origin
git push -u origin main
```

## Create a PR template (optional)
Use the following PR body when creating the initial PR:

```
Title: feat: initial EcoReceipt starter MVP

Summary:
- React + Vite frontend demo (scan, result, dashboard)
- Node + Express backend (mock OCR + carbon estimator)
- Supabase schema + integration skeleton
- Google Vision & Climatiq integration stubs
- Unit tests + GitHub Actions CI
- Demo assets and animated GIF

How to test locally:
1. Start backend: cd backend && npm install && npm run dev
2. Start frontend: cd frontend && npm install && npm run dev
3. Visit http://localhost:5173 and try sample receipts.

Notes:
- Set environment variables in GitHub Secrets for production features (GOOGLE_VISION_API_KEY, CLIMATIQ_API_KEY, SUPABASE_URL, SUPABASE_KEY).
- Use the infra/supabase_schema.sql to initialize your Supabase tables.

Reviewers:
- @your-team
```

## Suggested branch & PR rules
- Create feature branches for major changes: `feat/ocr-google`, `feat/supabase`, `feat/climatiq`
- Open PRs against `main` with description and checklist.
