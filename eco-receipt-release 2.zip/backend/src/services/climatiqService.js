// Climatiq integration stub
// Use CLIMATIQ_API_KEY env var to enable. This file provides a function to lookup emission factors.
import fetch from 'node-fetch';

const API_KEY = process.env.CLIMATIQ_API_KEY || null;
const BASE = 'https://beta3.api.climatiq.io';

export async function lookupEmissionFactor(category, params={}) {
  if (!API_KEY) {
    console.warn('Climatiq API key not set; returning null.');
    return null;
  }
  try {
    // Example: search for emissions factors by parameters.
    // This is a lightweight example; for production use the official client and handle paging/rate limits.
    const res = await fetch(`${BASE}/search?source=Emissions%20Factors&query=${encodeURIComponent(category)}`, {
      headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' }
    });
    const json = await res.json();
    // Inspect json.results and pick a suitable factor (this is a stub)
    const candidate = json?.results?.[0] || null;
    if (!candidate) return null;
    return {
      name: candidate.name || candidate.source,
      co2e_g_per_unit: candidate.co2e_g_per_unit || null,
      raw: candidate
    };
  } catch (e) {
    console.warn('Climatiq lookup error', e?.message || e);
    return null;
  }
}
