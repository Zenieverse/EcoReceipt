Demo script (approx 2:30)
1. Intro (0:00-0:10) - "Hi, I'm ... EcoReceipt..."
2. Problem (0:10-0:30)
3. Live demo: Scan a receipt (0:30-1:10)
   - Show Scan page, upload image, processing, Result page
4. Dashboard (1:10-1:40)
5. Tech & Roadmap (1:40-2:10)
6. Close (2:10-2:30)
