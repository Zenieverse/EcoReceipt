// OCR service: uses Google Vision if credentials provided, otherwise falls back to mock or Tesseract.
import fs from 'fs';
import fetch from 'node-fetch';
import { tesseractOCR } from './tesseractService.js';

const USE_GOOGLE = !!process.env.GOOGLE_VISION_API_KEY || !!process.env.GOOGLE_APPLICATION_CREDENTIALS;

export async function mockProcessImageOCR(imageBase64) {
  // For faster demo, return a sample receipt text
  return `Caffe Good
Medium Latte - 4.50
Blueberry Muffin - 3.00
Bottle Water - 1.50
Total - 9.00`;
}

async function callGoogleVisionBase64(imageBase64) {
  const apiKey = process.env.GOOGLE_VISION_API_KEY;
  if (!apiKey) throw new Error('GOOGLE_VISION_API_KEY not set');
  const body = {
    requests: [
      {
        image: { content: imageBase64.split(',').pop() },
        features: [{ type: 'TEXT_DETECTION', maxResults: 1 }]
      }
    ]
  };
  const res = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const json = await res.json();
  const text = json?.responses?.[0]?.fullTextAnnotation?.text || '';
  return text;
}

export async function processImageOCR(imageBase64) {
  try {
    if (USE_GOOGLE) {
      const txt = await callGoogleVisionBase64(imageBase64);
      if (txt && txt.trim().length>0) return txt;
    }
  } catch (e) {
    console.warn('Google Vision failed:', e?.message || e);
  }

  // Try Tesseract.js as a local OCR fallback
  try {
    const ttxt = await tesseractOCR(imageBase64);
    if (ttxt && ttxt.trim().length>0) return ttxt;
  } catch (e) {
    console.warn('Tesseract fallback failed:', e?.message || e);
  }

  // final fallback: mock
  return await mockProcessImageOCR(imageBase64);
}
