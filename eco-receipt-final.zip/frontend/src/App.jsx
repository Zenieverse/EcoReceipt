import React from 'react';
import ScanPage from './pages/ScanPage';
import ResultPage from './pages/ResultPage';
import Dashboard from './pages/Dashboard';
import { useState } from 'react';

export default function App(){
  const [view, setView] = useState('scan');
  const [result, setResult] = useState(null);
  return (
    <div style={{fontFamily:'Inter, system-ui, sans-serif', padding:20, maxWidth:720, margin:'0 auto'}}>
      <header><h1>EcoReceipt (demo)</h1></header>
      {view==='scan' && <ScanPage onResult={(r)=>{ setResult(r); setView('result')}} />}
      {view==='result' && <ResultPage data={result} onBack={()=>setView('scan')} onDashboard={()=>setView('dashboard')} />}
      {view==='dashboard' && <Dashboard data={result} onBack={()=>setView('scan')} />}
      <footer style={{marginTop:40, fontSize:12, color:'#666'}}>Starter demo — replace mock services with real APIs for production.</footer>
    </div>
  )
}
