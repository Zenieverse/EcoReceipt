// Supabase skeleton service using @supabase/supabase-js
// This file provides basic saveReceipt and getUserDashboard functions.
import { createClient } from '@supabase/supabase-js';

const URL = process.env.SUPABASE_URL || '';
const KEY = process.env.SUPABASE_KEY || '';

export const supabase = (URL && KEY) ? createClient(URL, KEY) : null;

export async function saveReceiptToSupabase(userId, receipt) {
  if (!supabase) {
    console.warn('Supabase not configured — skipping save');
    return null;
  }
  const { data, error } = await supabase
    .from('receipts')
    .insert([{ user_id: userId, raw_text: receipt.raw_text, total_amount: receipt.total_amount || null, metadata: receipt }])
    .select()
    .limit(1);
  if (error) throw error;
  return data?.[0] || null;
}

export async function getUserReceipts(userId) {
  if (!supabase) return [];
  const { data, error } = await supabase
    .from('receipts')
    .select('*')
    .eq('user_id', userId)
    .order('uploaded_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return data || [];
}
