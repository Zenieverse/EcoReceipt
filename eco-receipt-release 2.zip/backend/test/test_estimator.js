import assert from 'assert';
import { estimateCarbonForItems } from '../src/services/carbonEstimator.js';

async function run() {
  const items = [
    { name: 'Medium Latte', quantity: 1 },
    { name: 'Blueberry Muffin', quantity: 1 },
    { name: 'Beef Steak', quantity: 1 }
  ];
  const results = await estimateCarbonForItems(items);
  console.log('Estimator results:', results);
  assert(results.length === 3, 'should return 3 items');
  const latte = results.find(r=>r.name.toLowerCase().includes('latte'));
  assert(latte && latte.est_co2_kg > 0, 'latte should have co2');
  const beef = results.find(r=>r.name.toLowerCase().includes('beef'));
  assert(beef && beef.category==='beef', 'beef category');
  console.log('All tests passed.');
}

run().catch(e=>{ console.error(e); process.exit(1); });
