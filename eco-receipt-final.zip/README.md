# EcoReceipt — Carbon tracking from receipts (Starter Repo)

This repository contains a starter MVP for **EcoReceipt**: a receipt-to-carbon tracking Progressive Web App (PWA).
It includes a minimal frontend (React + Vite), a minimal backend (Node + Express) with a mock OCR/estimator,
sample carbon lookup data, and instructions to run locally.

## What’s included
- `frontend/` — React Vite app (scan page, result page, dashboard)
- `backend/` — Express server with `/api/scan` endpoint (mock OCR + estimator)
- `infra/` — sample `carbon_lookup.json`
- `demo-assets/` — logo and demo script

## Quickstart (local)
Requirements: Node 18+, npm

1. Start backend
```bash
cd backend
npm install
npm run dev
```
Backend runs at http://localhost:4000

2. Start frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend runs at http://localhost:5173

3. Try scanning:
- Use the Scan page to upload a receipt image (the backend uses a mock OCR and will parse simple test text).

## Notes
- This is a **starter** codebase intended for hackathon MVP. Replace mock OCR with Google Vision or Tesseract for production.
- Add OpenAI classification or keyword rules to improve item recognition.
- Replace local carbon lookup with Climatiq or Greenly API for authoritative emission factors.

## Demo & Submission Checklist
- Working demo URL or instructions to run locally
- GitHub repo with README, code, and demo video
- Demo video (2–4 minutes): show scan → result → dashboard flow

--- End of README


## Extended features added

- Google Vision OCR integration stub: set `GOOGLE_VISION_API_KEY` or `GOOGLE_APPLICATION_CREDENTIALS` to enable.
- Supabase skeleton integration: set `SUPABASE_URL` and `SUPABASE_KEY` to enable saving receipts.
- Demo receipts included in `demo-receipts/` for quick testing.
- Simple node test for the carbon estimator: `cd backend && npm install && npm run test`.
- GitHub Actions workflow will run tests and build frontend (see `.github/workflows/ci.yml`).


## New additions (automated)

- Climatiq integration stub: backend/src/services/climatiqService.js — set `CLIMATIQ_API_KEY` to enable lookups.
- Supabase schema SQL: infra/supabase_schema.sql (create tables with supabase or psql).
- GitHub push & PR instructions: docs/git_push_and_pr.md
- Animated demo GIF: demo-assets/animated-demo.gif (use in README or submission slides).


## Final additions (Implemented)

- Tesseract.js server-side OCR fallback: `backend/src/services/tesseractService.js` and `ocrService` updated to call it.
- GitHub push script: `scripts/create_and_push_repo.sh` (uses `gh` CLI) — run locally to create and push the repo.
- Professional narration & storyboard: `demo-assets/narration_storyboard.md`.
