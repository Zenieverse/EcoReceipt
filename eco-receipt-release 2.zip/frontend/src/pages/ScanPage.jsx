import React, {useState} from 'react';
import axios from 'axios';

export default function ScanPage({ onResult }){
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(null);

  async function handleFile(e){
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      setPreview(reader.result);
      setLoading(true);
      try {
        const res = await axios.post('http://localhost:4000/api/scan', { imageBase64: reader.result });
        onResult(res.data);
      } catch (err) {
        alert('Scan failed: ' + String(err));
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  }

  async function useSample(name){
    setLoading(true);
    try {
      const txt = await fetch('/demo-receipts/' + name).then(r=>r.text());
      const res = await axios.post('http://localhost:4000/api/scan', { raw_text: txt });
      onResult(res.data);
    } catch(e){
      alert('Sample load failed: ' + String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h2>Scan Receipt</h2>
      <p>Upload a receipt image (demo uses mock OCR)</p>
      <input type="file" accept="image/*" onChange={handleFile} />
      <div style={{marginTop:12}}>
        <strong>Or try sample receipts:</strong>
        <div style={{marginTop:8}}>
          <button onClick={()=>useSample('receipt1.txt')}>Sample: Cafe</button>
          <button style={{marginLeft:8}} onClick={()=>useSample('receipt2.txt')}>Sample: Grocery</button>
          <button style={{marginLeft:8}} onClick={()=>useSample('receipt3.txt')}>Sample: FastFood</button>
        </div>
      </div>
      {preview && <img src={preview} alt="preview" style={{maxWidth:320, marginTop:12}} />}
      {loading && <p>Processing…</p>}
    </div>
  )
}
